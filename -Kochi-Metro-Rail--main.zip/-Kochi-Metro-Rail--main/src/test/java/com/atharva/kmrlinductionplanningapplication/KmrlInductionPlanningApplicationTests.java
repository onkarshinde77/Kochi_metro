package com.atharva.kmrlinductionplanningapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KmrlInductionPlanningApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.atharva.kmrlinductionplanningapplication.exception;

public class GlobalExceptionHandler extends Exception {
    public GlobalExceptionHandler(String message) {
        super(message);
    }
}

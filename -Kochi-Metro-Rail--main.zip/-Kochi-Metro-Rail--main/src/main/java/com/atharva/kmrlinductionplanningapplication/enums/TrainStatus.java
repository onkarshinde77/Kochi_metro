package com.atharva.kmrlinductionplanningapplication.enums;

public enum TrainStatus {
    ACTIVE,
    IN_SERVICE,
    MAINTENANCE,
    RETIRED
}
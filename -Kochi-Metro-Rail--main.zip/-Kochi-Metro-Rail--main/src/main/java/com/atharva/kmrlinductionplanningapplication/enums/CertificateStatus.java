package com.atharva.kmrlinductionplanningapplication.enums;

public enum CertificateStatus {
    VALID,
    EXPIRED,
    PENDING,
    REVOKED
}

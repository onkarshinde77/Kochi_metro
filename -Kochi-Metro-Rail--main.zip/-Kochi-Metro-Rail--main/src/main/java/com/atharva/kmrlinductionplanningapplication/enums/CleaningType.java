package com.atharva.kmrlinductionplanningapplication.enums;


public enum CleaningType {
    INTERIOR,
    EXTERIOR,
    DEEP_CLEAN
}
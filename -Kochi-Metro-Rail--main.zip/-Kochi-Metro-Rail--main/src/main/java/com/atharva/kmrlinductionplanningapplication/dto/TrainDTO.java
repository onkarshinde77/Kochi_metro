package com.atharva.kmrlinductionplanningapplication.dto;

public class TrainDTO {
}

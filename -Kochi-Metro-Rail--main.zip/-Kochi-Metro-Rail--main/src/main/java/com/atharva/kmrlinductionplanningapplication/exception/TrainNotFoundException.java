package com.atharva.kmrlinductionplanningapplication.exception;

public class TrainNotFoundException extends Exception {
 public TrainNotFoundException(String message) {
     super(message);
 }
}

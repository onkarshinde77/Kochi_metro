package com.atharva.kmrlinductionplanningapplication.enums;

public enum Department {
    ROLLING_STOCK,
    SIGNALLING,
    TELECOM
}

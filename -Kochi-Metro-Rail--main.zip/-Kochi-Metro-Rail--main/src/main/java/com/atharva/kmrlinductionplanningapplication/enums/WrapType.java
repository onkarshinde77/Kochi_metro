package com.atharva.kmrlinductionplanningapplication.enums;


public enum WrapType {
    FULL,
    PARTIAL,
    PANEL
}
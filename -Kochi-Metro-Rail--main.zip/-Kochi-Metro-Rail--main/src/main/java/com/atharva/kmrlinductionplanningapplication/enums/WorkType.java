package com.atharva.kmrlinductionplanningapplication.enums;

public enum WorkType {
    PREVENTIVE,
    CORRECTIVE
}
